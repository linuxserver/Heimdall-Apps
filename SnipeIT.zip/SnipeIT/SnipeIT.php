<?php namespace App\SupportedApps\SnipeIT;

class SnipeIT extends \App\SupportedApps {

}