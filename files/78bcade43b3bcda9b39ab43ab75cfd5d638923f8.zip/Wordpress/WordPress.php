<?php namespace App\SupportedApps\Wordpress;

class Wordpress extends \App\SupportedApps
{
}
