<?php namespace App\SupportedApps\Jitsi;

class Jitsi extends \App\SupportedApps {

}