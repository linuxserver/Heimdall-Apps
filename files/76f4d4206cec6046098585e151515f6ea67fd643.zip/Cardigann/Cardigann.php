<?php

namespace App\SupportedApps\Cardigann;

class Cardigann extends \App\SupportedApps
{
}
