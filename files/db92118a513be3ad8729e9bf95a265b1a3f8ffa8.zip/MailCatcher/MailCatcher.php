<?php

namespace App\SupportedApps\MailCatcher;

class MailCatcher extends \App\SupportedApps
{
}
