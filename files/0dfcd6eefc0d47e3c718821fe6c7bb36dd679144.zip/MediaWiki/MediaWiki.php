<?php namespace App\SupportedApps\MediaWiki;

class MediaWiki extends \App\SupportedApps
{
}
