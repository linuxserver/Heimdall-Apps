<?php

namespace App\SupportedApps\Hoarder;

class Hoarder extends \App\SupportedApps
{
}
