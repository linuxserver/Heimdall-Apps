<?php namespace App\SupportedApps\SickBeard;

class SickBeard extends \App\SupportedApps {

}