<?php namespace App\SupportedApps\Firefly;

class Firefly extends \App\SupportedApps {

}