<?php

namespace App\SupportedApps\SemaphoreUI;

class SemaphoreUI extends \App\SupportedApps
{
}
