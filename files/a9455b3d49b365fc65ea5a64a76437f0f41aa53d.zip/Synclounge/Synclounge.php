<?php

namespace App\SupportedApps\Synclounge;

class Synclounge extends \App\SupportedApps
{
}
