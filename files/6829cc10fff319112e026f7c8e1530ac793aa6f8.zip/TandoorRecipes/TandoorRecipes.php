<?php

namespace App\SupportedApps\TandoorRecipes;

class TandoorRecipes extends \App\SupportedApps
{
}
