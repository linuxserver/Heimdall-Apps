<ul class="livestats">
    <li>
        <span class="title">servers:</span><strong>{!! $servers_total !!}</strong>
        <span class="title">players:</span><strong>{!! $players_online !!}</strong>
    </li>
    <li>
        <span class="title">online:</span><strong>{!! $servers_online !!}</strong>
        <span class="title">memory:</span><strong>{!! $mem !!} GB</strong>
    </li>
</ul>