<ul class="livestats">
    @if ($unread > 0)
        <li>
            <span class="title">Unread</span><strong>{!! $unread !!}</strong>
        </li>
    @endif
</ul>
