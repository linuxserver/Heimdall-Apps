<?php

namespace App\SupportedApps\Guacamole;

class Guacamole extends \App\SupportedApps
{
}
