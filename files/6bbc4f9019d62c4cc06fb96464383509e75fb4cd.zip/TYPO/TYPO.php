<?php namespace App\SupportedApps\TYPO;

class TYPO extends \App\SupportedApps {

}