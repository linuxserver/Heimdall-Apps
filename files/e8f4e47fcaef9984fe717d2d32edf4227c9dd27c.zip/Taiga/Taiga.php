<?php

namespace App\SupportedApps\Taiga;

class Taiga extends \App\SupportedApps
{
}
