<?php

namespace App\SupportedApps\LazyLibrarian;

class LazyLibrarian extends \App\SupportedApps
{
}
