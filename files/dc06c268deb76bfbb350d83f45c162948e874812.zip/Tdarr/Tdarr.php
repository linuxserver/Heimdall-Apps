<?php namespace App\SupportedApps\Tdarr;

class Tdarr extends \App\SupportedApps {

}