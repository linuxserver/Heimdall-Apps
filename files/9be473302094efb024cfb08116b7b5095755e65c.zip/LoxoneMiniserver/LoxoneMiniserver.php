<?php

namespace App\SupportedApps\LoxoneMiniserver;

class LoxoneMiniserver extends \App\SupportedApps
{
}
