<?php

namespace App\SupportedApps\Obsidian;

class Obsidian extends \App\SupportedApps
{
}
