<ul class="livestats">
    <li>
        <span class="title">Movies</span>
        <strong>{!! $movies !!}</strong>
    </li>
    <li>
        <span class="title">Episodes</span>
        <strong>{!! $series !!}</strong>
    </li>
</ul>
