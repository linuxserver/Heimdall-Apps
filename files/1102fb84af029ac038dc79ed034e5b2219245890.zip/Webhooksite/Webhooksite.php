<?php

namespace App\SupportedApps\Webhooksite;

class Webhooksite extends \App\SupportedApps
{
}
