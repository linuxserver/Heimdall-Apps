<?php namespace App\SupportedApps\AVMFritzbox;

class AVMFritzbox extends \App\SupportedApps {

}