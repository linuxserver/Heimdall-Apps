<?php

namespace App\SupportedApps\EmulatorJS;

class EmulatorJS extends \App\SupportedApps
{
}
