<?php namespace App\SupportedApps\Jupyter;

class Jupyter extends \App\SupportedApps
{
}
