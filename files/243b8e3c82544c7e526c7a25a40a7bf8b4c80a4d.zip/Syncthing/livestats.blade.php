<ul class="livestats">
    <li>
        <span class="title">Needed Files</span>
        <strong>{!! $needed_files !!}</strong>
    </li>
    <li>
        <span class="title">Needed Gigabytes</span>
        <strong>{!! round($needed_bytes / 1073741824, 2) !!} GB</strong>
    </li>
</ul>
