<?php namespace App\SupportedApps\PlexRequests;

class PlexRequests extends \App\SupportedApps
{
}
