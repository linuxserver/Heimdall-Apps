<?php

namespace App\SupportedApps\Forgejo;

class Forgejo extends \App\SupportedApps
{
}
