<?php

namespace App\SupportedApps\Strapi;

class Strapi extends \App\SupportedApps
{
}
