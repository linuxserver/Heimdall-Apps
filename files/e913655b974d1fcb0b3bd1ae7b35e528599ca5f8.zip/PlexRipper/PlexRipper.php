<?php

namespace App\SupportedApps\PlexRipper;

class PlexRipper extends \App\SupportedApps
{
}
