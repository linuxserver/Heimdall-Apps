<?php namespace App\SupportedApps\NexusRepositoryManagerOSSx;

class NexusRepositoryManagerOSSx extends \App\SupportedApps {

}