<?php

namespace App\SupportedApps\RocketChat;

class RocketChat extends \App\SupportedApps
{
}
