<?php

namespace App\SupportedApps\OpenCCU;

class OpenCCU extends \App\SupportedApps
{
}
