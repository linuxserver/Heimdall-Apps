<?php

namespace App\SupportedApps\Servas;

class Servas extends \App\SupportedApps
{
}
