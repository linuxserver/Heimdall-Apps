<?php namespace App\SupportedApps\Jenkins;

class Jenkins extends \App\SupportedApps {

}