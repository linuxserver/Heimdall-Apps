<?php

namespace App\SupportedApps\Box;

class Box extends \App\SupportedApps
{
}
