<?php

namespace App\SupportedApps\Traggo;

class Traggo extends \App\SupportedApps
{
}
