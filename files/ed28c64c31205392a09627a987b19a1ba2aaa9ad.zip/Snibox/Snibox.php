<?php namespace App\SupportedApps\Snibox;

class Snibox extends \App\SupportedApps
{
}
