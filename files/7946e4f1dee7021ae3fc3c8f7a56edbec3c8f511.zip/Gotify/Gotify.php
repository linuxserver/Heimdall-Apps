<?php

namespace App\SupportedApps\Gotify;

class Gotify extends \App\SupportedApps implements \App\EnhancedApps
{
}
