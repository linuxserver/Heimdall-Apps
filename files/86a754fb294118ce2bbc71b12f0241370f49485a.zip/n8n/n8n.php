<?php namespace App\SupportedApps\neightn;

class neightn extends \App\SupportedApps
{
}
