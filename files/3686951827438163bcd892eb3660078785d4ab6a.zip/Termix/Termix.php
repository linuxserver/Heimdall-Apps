<?php

namespace App\SupportedApps\Termix;

class Termix extends \App\SupportedApps
{
}
