<ul class="livestats">
    <li>
        <span class="title">Queries<br />Blocked</span>
        <strong>{!! $queries_blocked !!}</strong>
    </li>
    <li>
        <span class="title">Percent<br /> Blocked</span>
        <strong>{!! $percent_blocked !!}</strong>
    </li>
</ul>
