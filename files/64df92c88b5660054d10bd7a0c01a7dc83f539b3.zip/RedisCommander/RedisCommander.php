<?php

namespace App\SupportedApps\RedisCommander;

class RedisCommander extends \App\SupportedApps
{
}
