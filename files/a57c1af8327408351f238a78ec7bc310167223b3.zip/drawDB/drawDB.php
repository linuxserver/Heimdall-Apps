<?php

namespace App\SupportedApps\drawDB;

class drawDB extends \App\SupportedApps // phpcs:ignore
{
}
