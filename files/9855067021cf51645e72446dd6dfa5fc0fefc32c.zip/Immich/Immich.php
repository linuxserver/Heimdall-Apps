<?php

namespace App\SupportedApps\Immich;

class Immich extends \App\SupportedApps
{
}
