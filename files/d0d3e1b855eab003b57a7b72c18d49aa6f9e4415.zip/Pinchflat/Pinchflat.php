<?php

namespace App\SupportedApps\Pinchflat;

class Pinchflat extends \App\SupportedApps
{
}
