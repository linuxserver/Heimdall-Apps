<ul class="livestats">
    <li>
        <span class="title">Down</span>
        <strong>{!! $avg_down . 'Mbps' !!}</strong>
    </li>
    <li>
        <span class="title">Up</span>
        <strong>{!! $avg_up . 'Mbps' !!}</strong>
    </li>
</ul>