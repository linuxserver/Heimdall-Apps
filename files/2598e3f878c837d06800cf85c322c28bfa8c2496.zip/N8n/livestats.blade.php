<ul class="livestats">
    <li>
        <span class="title">Workflows</span>
        <strong>{!! $workflows !!}</strong>
    </li>
    <li>
        <span class="title">Active</span>
        <strong>{!! $active !!}</strong>
    </li>
</ul>
