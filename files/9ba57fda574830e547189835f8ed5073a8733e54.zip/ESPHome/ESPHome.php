<?php namespace App\SupportedApps\ESPHome;

class ESPHome extends \App\SupportedApps {

}