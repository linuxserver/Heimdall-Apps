<ul class="livestats">
    <li>
        <span class="title">Up</span>
        <strong>{!! $up ?? 0 !!}</strong>
    </li>
    <li>
        <span class="title">Down</span>
        <strong>{!! $down ?? 0 !!}</strong>
    </li>
</ul>
