<ul class="livestats">
    <li>
        <span class="title">Queries<br />Blocked</span>
        <strong>{!! $ads_blocked !!}</strong>
    </li>
    <li>
        <span class="title">Percent<br /> Blocked</span>
        <strong>{!! $ads_percentage !!}</strong>
    </li>
</ul>
