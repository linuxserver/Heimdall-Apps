<?php

namespace App\SupportedApps\TeslaLogger;

class TeslaLogger extends \App\SupportedApps
{
}
