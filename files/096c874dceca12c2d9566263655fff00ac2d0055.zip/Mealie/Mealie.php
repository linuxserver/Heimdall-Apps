<?php namespace App\SupportedApps\Mealie;

class Mealie extends \App\SupportedApps {

}