<?php

namespace App\SupportedApps\bitShake;

class bitShake extends \App\SupportedApps // phpcs:ignore
{
}
