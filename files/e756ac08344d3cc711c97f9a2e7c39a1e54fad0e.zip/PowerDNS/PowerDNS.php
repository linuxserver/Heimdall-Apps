<?php

namespace App\SupportedApps\PowerDNS;

class PowerDNS extends \App\SupportedApps
{
}
