<?php

namespace App\SupportedApps\Piwigo;

class Piwigo extends \App\SupportedApps
{
}
