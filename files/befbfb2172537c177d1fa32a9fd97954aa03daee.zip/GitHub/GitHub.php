<?php namespace App\SupportedApps\GitHub;

class GitHub extends \App\SupportedApps {

}