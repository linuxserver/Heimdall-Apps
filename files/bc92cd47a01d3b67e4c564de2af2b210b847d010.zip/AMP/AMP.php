<?php namespace App\SupportedApps\AMP;

class AMP extends \App\SupportedApps {

}