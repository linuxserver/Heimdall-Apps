<?php

namespace App\SupportedApps\Sourcegraph;

class Sourcegraph extends \App\SupportedApps
{
}
