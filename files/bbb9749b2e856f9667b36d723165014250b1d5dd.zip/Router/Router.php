<?php namespace App\SupportedApps\Router;

class Router extends \App\SupportedApps
{
}
