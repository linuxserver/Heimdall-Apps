<ul class="livestats">
    <li>
        <span class="title">Queue</span>
        <strong>{!! $queue !!}</strong>
    </li>
    <li>
        <span class="title">{!! $second_label !!}</span>
        <strong>{!! $second_value !!}</strong>
    </li>
</ul>
