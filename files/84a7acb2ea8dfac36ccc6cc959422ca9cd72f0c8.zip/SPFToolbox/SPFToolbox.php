<?php

namespace App\SupportedApps\SPFToolbox;

class SPFToolbox extends \App\SupportedApps
{
}
