<?php

namespace App\SupportedApps\ReportServer;

class ReportServer extends \App\SupportedApps
{
}
